args=commandArgs(trailingOnly = FALSE)

print(args)
# study = as.numeric(args[3])
# 
# setwd("/capecchi/pharmacy/morgunlab/lina/imsys/Project_03mp")
# 
# table = read.table( paste("/media/Storage/imsys/cor_dircor_table_byblocks_dados", study ,".txt", sep = ""), header = T)
# 
# print(nrow(table1))
# indeces = round(runif(100000,1,nrow(table1)))
# 
# write.table = (table1[indeces,], "cor_dircor_table_byblocks_dados1_randomSample.txt", col.names = T, row.names = F, sep = "\t")
