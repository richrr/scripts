# input
nodeIdMappingFile = "path/nodeIdMapping.txt"
idNetworkFile = "path/testNetwork1.txt"


nodeIdMappingData = read.table(nodeIdMappingFile,header=TRUE,stringsAsFactors=FALSE,sep="\t",quote="\"")
row.names(nodeIdMappingData) = nodeIdMappingData[,1]
head(nodeIdMappingData)

library(igraph)

myNetwork = read.graph(idNetworkFile,format = "edgelist",directed = FALSE)

E(myNetwork)

SeedNodes = nodeIdMappingData[nodeIdMappingData[,3]=="SEED",2]
HostNodes = nodeIdMappingData[nodeIdMappingData[,3]=="Host",2]

allPairs = expand.grid(SeedNodes,HostNodes)
# create a matrix , with each entry recording for each node(in a column), if it appears(not 1 or 0, but a normalized number, since there can be more than one shortest path between a pair of nodes) in the shortest path between a pair of nodes(in a row), the rows contain all pairs of nodes between two groups. Thus the sum of each column is the betweeness centrality for the node(in that column)
sumAllFractionsForAllNodes = matrix(0,ncol=length(SeedNodes)
									,nrow=nrow(allPairs)
									,dimnames= list(
													paste(as.vector(t(allPairs[1])),as.vector(t(allPairs[2])),sep="_")
													, as.character(SeedNodes)
													)
)


getShortestPaths = function(pair){  # for each row in "sumAllFractionsForAllNodes", calculate the values for the columns and update this row in "sumAllFractionsForAllNodes"
	print(pair)
	allShortestPaths = get.all.shortest.paths(myNetwork, from= pair[1], to= pair[2], mode = "all", weights=NULL) # calculate the shortest paths
	getFractionForAllNodes(allShortestPaths,pair)
}
getFractionForAllNodes = function(allShortestPaths,pair){	# for the shortest paths between a pairs of nodes, calculate the normalized number of appearence for the nodes that are in the shortest paths
	if (length(allShortestPaths$res)==0){  # if there is no shortest path, do not update "sumAllFractionsForAllNodes"
		fractions = cbind(SeedNodes,rep(0,times=length(SeedNodes)))
		print("no paths")
	}else{
		allShortestPaths = do.call(rbind,allShortestPaths$res) # a matrix with each row containing a shortest path between the two nodes

		nodesInPath = as.vector(allShortestPaths[,c(-1,-ncol(allShortestPaths))]) # get rid of the two nodes that are under study, the nodes in the shortest paths are extracted into this vector
		count = table(as.factor(nodesInPath))/nrow(allShortestPaths) # for each node in the shortest paths, calculate how many times(normalized) it appears
		columnsForUpdate = as.character(intersect(names(count),SeedNodes))
		sumAllFractionsForAllNodes[paste(pair,collapse="_"),columnsForUpdate] <<- count[columnsForUpdate]  # update the value for only the nodes in the shortest paths("names(count)") and of interest("SeedNodes")
	}	
}
td = apply(as.matrix(allPairs)[4000:6000,],1,getShortestPaths)

forPlot = colSums(sumAllFractionsForAllNodes)  # calculate betweeness centrality for the nodes in the columns
forPlot
library(ggplot2)
qplot(forPlot,data=as.data.frame(forPlot) ,geom="density")






